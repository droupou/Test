
#if !defined(__undef_short_h__) && !defined(MYSQL_FORCE_UNDEF)
#define __undef_short_h__

// defs.h
#undef use_exceptions

// base.h           
#undef BadQuery
#undef MysqlCon
#undef Connection

// result.h
#undef ResNSel
#undef ResUse
#undef Res
#undef Result
#undef ResIter
#undef ResultIter

// field_names.h
#undef FieldNames

//query.h
#undef Query

//string.h
#undef BadConversion
#undef ColData

// manip.h
#undef quote
#undef quote_only
#undef quote_double_only
#undef escape
#undef do_nothing
#undef ignore

// datetime.h
#undef Date
#undef Time
#undef DateTime

// set.h
#undef Set

// null.h
#undef Null
#undef null_type
#undef null
#undef NullisNull
#undef NullisZero
#undef NullisBlank

#endif
