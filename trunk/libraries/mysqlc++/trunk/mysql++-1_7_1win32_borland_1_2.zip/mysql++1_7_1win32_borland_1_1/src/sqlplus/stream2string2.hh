
#include "stream2string1.hh"
