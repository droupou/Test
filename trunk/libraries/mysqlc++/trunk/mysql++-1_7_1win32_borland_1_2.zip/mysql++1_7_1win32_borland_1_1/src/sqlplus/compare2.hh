
#include "compare1.hh"
